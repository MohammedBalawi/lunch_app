import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:launch_app/Screen/Invoice/invoice_screen.dart';
import 'package:launch_app/cv/my_cv_screen.dart';
import 'package:provider/provider.dart';
import 'Screen/Chat/chat_screen.dart';
import 'Screen/Files/search_screen.dart';
import 'Screen/Files/send_screen.dart';
import 'Screen/Files/upload_screen.dart';
import 'Screen/Favorites/favorites_screen.dart';

import 'Screen/pages/admin_screen.dart';
import 'Screen/pages/home_screen.dart';
import 'Screen/pages/login_screen.dart';
import 'Screen/Chat/privet_chat_screen.dart';
import 'Screen/Profiles/profile_screen.dart';
import 'Screen/Show/user.dart';
import 'firebase_options.dart';

final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
FlutterLocalNotificationsPlugin();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  runApp(
    MultiProvider(
    providers: [
      ChangeNotifierProvider(create: (_) => ChatProvider()),
    ],
    child: const MyApp(),
  ),);
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return
      MaterialApp(
      debugShowCheckedModeBanner: false,
      initialRoute: FirebaseAuth.instance.currentUser == null ? '/login' : '/home',
      routes: {
        '/login': (context) => const LoginScreen(),
        '/upload': (context) => const UploadFileScreen(),
        '/home': (context) => const HomeScreen(),
        '/invoice': (context) => const NameForm(),
        '/search': (context) => const SearchScreen(),
        '/chat': (context) => const ChatScreen(),
        '/chatt': (context) => const PrivetChatScreen(userEmail: ''),
        '/profile': (context) => const ProfileFormScreen(),
        '/edit': (context) => const ProfileDetailsScreen(),
        '/admin': (context) => const AdminScreen(),
        '/user': (context) => const UserProfilesScreen(),
        '/AdminnScreen': (context) => const SendScreen(email: ''),
        '/FileUploadScreen': (context) => const Favorites(),
        '/my_cv_screen': (context) => const MyCVScreen(),
      },
    );
  }
}