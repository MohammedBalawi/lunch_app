import 'dart:ui';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';

class NameForm extends StatefulWidget {
  const NameForm({super.key});

  @override
  _NameFormState createState() => _NameFormState();
}

class _NameFormState extends State<NameForm> {
  final _firstNameController = TextEditingController();
  final _secondNameController = TextEditingController();
  final _thirdNameController = TextEditingController();
  final _fourNameController = TextEditingController();
  final _fiveNameController = TextEditingController();

  List<String> _entries = [];

  @override
  void initState() {
    super.initState();
    _loadEntries();
  }

  void _showNames() async {
    if (_inputsAreEmpty()) {
      _showErrorMessage('Please fill all fields');
      return;
    }

    final date = DateFormat('yyyy/MM/dd HH:mm:ss').format(DateTime.now());
    final entry =
        '${_firstNameController.text}-${_secondNameController.text}-${_thirdNameController.text}-${_fourNameController.text}-${_fiveNameController.text}-$date';

    if (_entries.contains(entry)) {
      _showErrorMessage('Duplicate entry');
      return;
    }

    setState(() {
      _entries.insert(0, entry);
    });

    await _saveEntries();
  }

  void _editEntry(int index) async {
    final parts = _entries[index].split('-');
    if (parts.length < 6) return;

    _firstNameController.text = parts[0];
    _secondNameController.text = parts[1];
    _thirdNameController.text = parts[2];
    _fourNameController.text = parts[3];
    _fiveNameController.text = parts[4];

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Edit Entry'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _buildTextField(_firstNameController, 'Quantity Received'),
            _buildTextField(_secondNameController, 'Number of Recipients'),
            _buildTextField(_thirdNameController, 'Product Received'),
            _buildTextField(_fourNameController, 'Camp 1 '),
            _buildTextField(_fiveNameController, 'Camp 2 '),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
            },
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              final date =
                  DateFormat('yyyy/MM/dd HH:mm:ss').format(DateTime.now());
              final updatedEntry =
                  '${_firstNameController.text}-${_secondNameController.text}-${_thirdNameController.text}-${_fourNameController.text}-${_fiveNameController.text}-$date';

              setState(() {
                _entries[index] = updatedEntry;
              });

              _saveEntries();
              Navigator.of(context).pop();
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  void _sendToFirebase(String entry) async {
    final parts = entry.split('-');
    if (parts.length < 6) return;

    User? user = FirebaseAuth.instance.currentUser;
    String? email = user?.email;

    if (email == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('User not logged in')),
      );
      return;
    }

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => const Center(child: CircularProgressIndicator()),
    );

    try {
      await FirebaseFirestore.instance.collection('names').add({
        'firstName': parts[0],
        'secondName': parts[1],
        'thirdName': parts[2],
        'fourName': parts[3],
        'fiveName': parts[4],
        'date': parts[5],
        'senderEmail': email,
      });

      Navigator.of(context).pop();

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Data sent to Firebase')),
      );
    } catch (e) {
      Navigator.of(context).pop();

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to send data: $e')),
      );
    }
  }

  void _deleteEntry(int index) async {
    setState(() {
      _entries.removeAt(index);
    });
    await _saveEntries();
  }

  bool _inputsAreEmpty() {
    return _firstNameController.text.isEmpty ||
        _secondNameController.text.isEmpty ||
        _thirdNameController.text.isEmpty ||
        _fourNameController.text.isEmpty ||
        _fiveNameController.text.isEmpty;
  }

  void _showErrorMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  Future<void> _loadEntries() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _entries = prefs.getStringList('entries') ?? [];
    });
  }

  Future<void> _saveEntries() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('entries', _entries);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.yellow[700],
        title: const Text(
          'Name Form',
          style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8.0),
            child: Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(8),
                boxShadow: [
                  BoxShadow(
                      color: Colors.black.withOpacity(0.3),
                      spreadRadius: 2,
                      blurRadius: 5),
                ],
              ),
              child: IconButton(
                onPressed: () {
                  Navigator.pushReplacementNamed(context, '/home');
                },
                icon: const Icon(Icons.arrow_forward_ios_outlined),
              ),
            ),
          ),
        ],
      ),
      body: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          image: const DecorationImage(
            image: AssetImage('assets/image/parc.jpg'),
            fit: BoxFit.cover,
          ),
        ),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
          child: Container(
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0),
            ),
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    _buildTextField(_firstNameController, 'Quantity Received'),
                    _buildTextField(
                        _secondNameController, 'Number of Recipients'),
                    _buildTextField(_thirdNameController, 'Product Received'),
                    _buildTextField(_fourNameController, 'Camp 1 '),
                    _buildTextField(_fiveNameController, 'Camp 2 '),
                    const SizedBox(height: 20),
                    _buildButton('OK', _showNames),
                    const SizedBox(height: 20),
                    Expanded(
                      child: ListView.builder(
                        itemCount: _entries.length,
                        itemBuilder: (context, index) {
                          return _buildListItem(index);
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTextField(TextEditingController controller, String label) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: TextField(
        controller: controller,
        decoration: InputDecoration(
          labelText: label,
          border: const OutlineInputBorder(),
        ),
      ),
    );
  }

  Widget _buildButton(String label, VoidCallback onPressed) {
    return ElevatedButton(
      onPressed: onPressed,
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.white,
        padding: const EdgeInsets.symmetric(vertical: 15),
        textStyle: const TextStyle(fontSize: 16),
      ),
      child: Text(
        label,
        style: const TextStyle(color: Colors.black),
      ),
    );
  }

  Widget _buildListItem(int index) {
    final entry = _entries[index];
    final parts = entry.split('-');
    if (parts.length < 6) {
      return const Text('Invalid entry');
    }

    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8.0),
      color: Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(15),
      ),
      elevation: 4,
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildListText('Quantity Received: ${parts[0]}'),
            _buildListText('Number of Recipients: ${parts[1]}'),
            _buildListText('Product Received: ${parts[2]}'),
            _buildListText('Camp 1: ${parts[3]}'),
            _buildListText('Camp 2: ${parts[4]}'),
            _buildListText('Date: ${parts[5]}'),
            const SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                ElevatedButton(
                  onPressed: () => _editEntry(index),
                  style:
                      ElevatedButton.styleFrom(backgroundColor: Colors.orange),
                  child: const Text(
                    'Edit',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
                ElevatedButton(
                  onPressed: () => _sendToFirebase(entry),
                  style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blueAccent),
                  child: const Text(
                    'Send',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
                ElevatedButton(
                  onPressed: () => _deleteEntry(index),
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                  child: const Text(
                    'Delete',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildListText(String text) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Text(
        text,
        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
      ),
    );
  }
}
