import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class FirebaseDisplayScreen extends StatefulWidget {
  final String userEmail;

  const FirebaseDisplayScreen({super.key, required this.userEmail});

  @override
  _FirebaseDisplayScreenState createState() => _FirebaseDisplayScreenState();
}

class _FirebaseDisplayScreenState extends State<FirebaseDisplayScreen> {
  final _firestore = FirebaseFirestore.instance;
  late Stream<QuerySnapshot> _stream;

  @override
  void initState() {
    super.initState();
    _stream = _firestore
        .collection('names')
        .orderBy('date', descending: true)
        .snapshots();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Firebase Data',
            style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white)),
        backgroundColor: Colors.yellow[700],
        elevation: 10.0,
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: _stream,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }

          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return const Center(child: Text('No data found'));
          }

          final documents = snapshot.data!.docs;
          return ListView.builder(
            itemCount: documents.length,
            itemBuilder: (context, index) {
              final doc = documents[index];
              final data = doc.data() as Map<String, dynamic>;
              final firstName = data['firstName'];
              final secondName = data['secondName'];
              final thirdName = data['thirdName'];
              final fourName = data['fourName'];
              final fiveName = data['fiveName'];
              final date = data['date'];
              final senderEmail = data['senderEmail'];

              if (widget.userEmail == senderEmail) {
                return Card(
                  margin: const EdgeInsets.symmetric(
                      vertical: 8.0, horizontal: 16.0),
                  elevation: 6.0,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15),
                  ),
                  shadowColor: Colors.black54,
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _buildListText('💼 Quantity Received: $firstName'),
                        _buildListText('📦 Number of Recipients: $secondName'),
                        _buildListText('🎁 Product Received: $thirdName'),
                        _buildListText('🏕️ Camp 1: $fourName'),
                        _buildListText('🏕️ Camp 2: $fiveName'),
                        _buildListText('🕒 Date: $date'),
                        _buildListText('📧 Sender Email: $senderEmail',
                            color: Colors.blueAccent),
                      ],
                    ),
                  ),
                );
              }

              return Container();
            },
          );
        },
      ),
    );
  }

  Widget _buildListText(String text, {Color color = Colors.black}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Text(
        text,
        style: TextStyle(
          fontSize: 16,
          fontWeight: FontWeight.w500,
          color: color,
        ),
      ),
    );
  }
}
